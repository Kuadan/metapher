get.results.ds <-
function(d,
                           elem.number=NULL,
                           del.col=c(2,4),
                           col.names=c("region",
                                       "word",
                                       "rt",
                                       "line.break",
                                       "sentence"),
                           list=NULL,
                           sprt = TRUE,
                           save.to="") {
  
  # Ensure that we read ALL the columns from the file. 
  # If the user specified longer list of column names, add some empty columns. 
  if (is.character(d)) {  d <- read.ibex(d, col.names)
    
    } else {
    # check whether the data.frame has supposed number of columns
    if (NCOL(d)<12) stop ("DashedSentence controller creates 12 columns,\n",
                          "but the number of columns in the data.frame is less than 12.\n",
                          "Check whether the data was read into R completely")
  } 
  
  d <- d[d[3]=="DashedSentence",]
  if (NROW(d)==0) stop ("Subsetting for DashedSentence controller failed")
  d <- droplevels(d)
  
  if (sprt) {
    
    if (NCOL(d)<12) message("The mode of the data may be Acceptabilty Judgment, ",
                            "while you set the mode to sprt. ",
                            "Check the data. See IBEX manual for more details about the modes.\n")
    
    # ensuring correct types of data in the columns
    d[8] <- factor(d[[8]]) # region is a factor
    check.numeric(d[[10]], col.names[3])
    d[[10]] <- as.numeric(as.character(d[[10]])) # rt should be numeric
    
    
    # If line.break contains only FALSE, it can be deleted
    if (NROW(unique(d[11]))==1) if (d[1,11]=="False") del.col <- c(del.col,11) 
    
    # sprt defines mode for the controller in IBEX and, consequently,
    # the IBEX output. 
    
    res <- get.results(d, controller="DashedSentence",
                       elem.number, del.col, col.names,list, save.to)
  } else {
    
    if (NCOL(d)>8) message ("The mode of the data may be sprt, ",
                            "while you set the mode to Acceptability Judgment. ",
                            "Check the data. See IBEX manual for more details about the modes.\n")
    
    res <- get.results(d, controller="DashedSentence",
                elem.number, del.col, col.names="sentence",
                list, save.to)
  }
}
