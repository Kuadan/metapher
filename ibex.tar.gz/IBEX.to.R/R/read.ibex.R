read.ibex <-
function (d, col.names, ...) {
  
  if (!is.character(d)) stop ("d must be a character")
  
  n.cols <- 14
  
  col.names <- c("subject",
                 "md5.hash",
                 "controller",
                 "item.number",
                 "element.number",
                 "type",
                 "group", col.names)
  
  # If there are more column names specified than there are columns in the data,
  # add empty columns  
  if (n.cols<length(col.names)) n.cols <- length(col.names)
  if (n.cols>length(col.names)) 
    col.names <- c (col.names, paste0("Col",seq(from=length(col.names)+1, to=n.cols)))
  
  colClasses <- c("factor", "character", "character", "numeric","numeric", "character","character", rep(NA, n.cols-7))
  d <- read.csv(d,header=FALSE, fill=TRUE, comment.char="#", 
                col.names=col.names,
                colClasses=colClasses,
                as.is=FALSE, ...)
}
