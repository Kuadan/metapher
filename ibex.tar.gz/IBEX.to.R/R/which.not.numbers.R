which.not.numbers <-
function (x, names=TRUE){  
  NaN.ind <- numbers.only(levels(x))
  if (!is.null(NaN.ind)) {
    if (names) {return (as.character(levels(x)[NaN.ind]))}
    else return (grep("[^1234567890]", x))
  }
  else return(NULL)
}
