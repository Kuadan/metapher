get.subjects <-
function (d, form.name="intro", info=NULL, browser.info=FALSE, save.to="") {
  
  # Check the input data 
  if ((is.data.frame(d)==FALSE)&(is.character(d)==FALSE)) stop ("d must be either a data.frame or a character")
  if (is.character(form.name)==FALSE) stop ("form.name must be a character")
  if ((is.character(info)==FALSE) &(is.null(info)==FALSE)) stop ("info should be character")
  if (is.character(save.to)==FALSE) stop ("save.to must be a character")
  #---------------------------------------
  
  # handle duplicate values in the input
  info <- unique(info)
  
  # d may be either a string or a data.frame. If it is a string,
  # it should specify the filepath. Also, only if it's a string
  # we are going to read participant's browser info (I doubt that
  # somebody would read data.file with comment lines, so...)
  #
  # Ok, what we do here is searching for USER AGENT string, 
  # which indicates the browser info.
  
  if (browser.info&is.data.frame(d)) {
    warning ("d is data.frame. Browser Info will not be extracted")
    browser.info <- FALSE
  }
  
  if (browser.info&is.character(d)){
    raw.data <- read.csv(file=d, header = FALSE) 
    df.Browser.Info <- raw.data[grepl(pattern="# USER AGENT:", x=raw.data[,1]),]
    if (NROW(df.Browser.Info)==0) warning ("Browser info was not found!")
    else  df.Browser.Info[,1] <- paste(df.Browser.Info[,1],df.Browser.Info[,2],sep="") 
  } 

  if (is.character(d)) d <- read.ibex(d, col.names=c("field","answer"))

  if (NROW(d[d[3]=="Form",])==0) stop ("The Form controller isn't found in the data. ",
                                       "Possibly, the data doesn't contain subject info") 
  
  
  # Select info by controller type, which is Form here,
  # because Forms gather information from participants in IBEX.
  # Also, we don't want the Get.Result function to print the numbers
  # of columns that were deleted (none are in this call, since del.col=NULL)
  # So we use capture.output() function
  
  capture.output(form.df <- get.results(d,
                                        controller="Form",
                                        col.names=c("field","answer"),
                                        del.col=NULL))
  
  # User may specify the name of Form controller (in case
  # there are several forms in the experiment). Default name
  # in IBEX and here as well is "intro". 
  # If it is not specified at all,we subset only forms with this name.
  
  check.missing(x=form.name, string=form.df$type, "Forms")
  form.df <- form.df[form.df$type %in% form.name,]
  
  if (NROW(form.df)==0) stop ("Subsetting for form names failed") 
  
  # We get the number of participants by dividing the number of
  # entries by number of unique entry types (e.g. age, sex, etc)
    len <- length(form.df$field)/length(unique(form.df$field))
  
  # If the user hasn't specified which info he needs, we gather
  # everything what is contained in Field column.
  if (is.null(info)){
    info <- levels(form.df$field)
  }
  
  
  Subject.Info <- data.frame(matrix(nrow=len, ncol=length(info),
                                    dimnames=list(NULL, info)))
  
  # Names starting with _ are not valid in R.
  # So R appends X in the beggining. In the IBEX Form controller
  # reaction time is marked as _REACTION_TIME_, so R would "fix it" and
  # create a column named X_REACTION_TIME_. We don't need such a column,
  # and if there is _REACTION_TIME_ in the data, we remove this column.
  
  if ("_REACTION_TIME_" %in% info) {Subject.Info$X_REACTION_TIME_ <- NULL}
  
  # Subset by different fields. If a field doesn't exist,
  # the subset will have 0 rows, and this parameter should be
  # excluded from the final table. This is what happens in "if"
  # statement.
  
  for (i in 1:length(info))
  {
    if (NROW(form.df[form.df$field== info[i], ]) == 0){
      message ("Parameter \"", info[i], "\" wasn't found in the data.")   
      Subject.Info[info[i]] <- NULL
      next
    }
    temp <- form.df[form.df$field==info[i],]
    Subject.Info[info[i]] <- as.vector(temp$answer)
    
  }
  
  # Select unique values of Subject Codes
  Subject.Info$subject <- unique(form.df[,1])
  
  if (length(Subject.Info$subject)<len) warning ("Subject codes may be duplicate, check them")
  
  # if Browser Info was extracted, we add it.
  if (browser.info) if (NROW(df.Browser.Info)!=0) {
    Subject.Info$browser.info <- df.Browser.Info[,1]
  }
  
  # output some useful info
  cat("Number of subjects: ", len, "\n\n")
  cat("Info extracted:\n - ", paste(colnames(Subject.Info), collapse="\n - "), "\n\n")
  
  # saving the results to file, if asked
  if (save.to != "") {write.csv(res, file=paste(save.to,".csv",sep=""), row.names=FALSE)}
  
  return(Subject.Info)

}
