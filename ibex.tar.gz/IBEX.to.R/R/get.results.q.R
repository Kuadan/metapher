get.results.q <-
function(d,
                           elem.number=NULL,
                           del.col=c(2,4),
                           col.names=c("question",
                                       "answer",
                                       "is.correct",
                                       "rt"),
                           list=NULL,
                           save.to="") {

  # Ensure that we read ALL the columns from the file. 
  # If the user specified longer list of column names, add some empty columns. 
  if (is.character(d)) {d <- read.ibex(d, col.names)
  } else {
    # check whether the data.frame has supposed number of columns
    if (NCOL(d)<12) stop ("DashedSentence controller creates 12 columns,\n",
                          "but the number of columns in the data.frame is less than 12.\n",
                          "Check whether the data was read into R completely")
  } 
  
  d <- d[d[3]=="Question",]
  if (NROW(d)==0) stop ("Subsetting for Question controller failed")
  d <- d[1:11]
  d <- droplevels(d)
  
  # ensuring correct types of data in the columns
  check.numeric(d[[11]], col.names[4])  
  d[[11]] <- as.numeric(as.character(d[[11]])) # rt should be numeric
  
  # If Is.correct contains only NULL, it can be deleted
  if (NROW(unique(d[10]))==1) if (d[1,10]=="NULL") del.col <- c(del.col, 10) 

  
  get.results(d, controller="Question",
              elem.number, del.col, col.names, list, save.to)
}
